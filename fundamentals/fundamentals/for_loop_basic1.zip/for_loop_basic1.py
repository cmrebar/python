for i in range(0,151):
    print(i)
print("End of Task 1")
for i in range(5,1005,5):
    print(i)
print("End of Task 2")
for i in range(1,101):
    if i%5 == 0:
        print("Coding")
    if i%10 == 0:
        print("Coding Dojo")
print("End of Task 3")
sum = 0
for i in range(0,500000):
    sum += i
print(sum)
print("End of Task 4")
for i in range(2018,-1,-4):
    print(i)
print('End of Task 5')
lowNum = 3
highNum = 500
mult = 6
for i in range(lowNum, highNum):
    if i%mult == 0:
        print(i)
print('End of Task 6')